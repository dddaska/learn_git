<?php
include "header.php";
require_once "config.php";
?>
        <section class="product-page">
            <div class="tovar-img-page">
                <img src="./img/kriptokoshelek.jpg" alt="" width="600px" height="600px">
            </div>
            <div class="tovar-info-page">
                <h1>Аппаратный криптокошелек Ellipal X Card</h1>
                <br>
                <div class="bye">
                    <div class="price">
                    7 990 руб.
                    </div>
                    <button id="buyBtn">Купить</button>
                </div>
                <p><b>Описание</b></p>
                <p>Ультрабезопасный криптокошелек в формате кредитной карты</p>
                <br>
                <p>Обеспечьте максимальную защиту ваших криптоактивов с ELLIPAL X Card – компактным холодным кошельком, созданным для безопасного оффлайн-хранения. Этот инновационный кошелек сочетает передовые технологии и удобство, чтобы ваши средства оставались в безопасности.</p>
                <br>
                <p>Комплектация</p>
                <ol>
                    <li>
                        Три карты для Ellipal X Card
                    </li>
                    <li>
                        X Card Starter
                    </li>
                </ol>
            </div>
        </section>
    
    <script>
        const btn = document.getElementById('buyBtn')
        btn.addEventListener('click', (e)=>{
            alert('Поздравляем с покупкой!')
        })
    </script>
<?php
include "footer.php";
?>