<?php
include "header.php";
require_once "config.php";
?>
<?php
include "footer.php";
?>