<?php
include "header.php";
require_once "config.php";

$result = $connect->query("SELECT * FROM products");
$products = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
?>
<section class="popular-tovar">
    <h3>Популярные товары</h3>
    <div class="tovar-list">
        <?php foreach ($products as $product) : ?>
            <div class="tovar-card">
                <div class="tovar-img">
                    <img src="<?php echo $product['img']; ?>" alt="" width="250">
                </div>
                <div class="tovar-info">
                    <p><?php echo $product['name'] ?></p>
                    <a href="<?php echo $product['informationlink']; ?>"><?php echo $product['button']; ?></a>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</section>
<?php
include "footer.php";
?>