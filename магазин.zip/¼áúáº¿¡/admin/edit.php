<?php
require_once 'config.php';
$id = $_GET['id'];
$result = $connect->query("SELECT * FROM products WHERE id=$id");
$product = $result->fetch_assoc();
if (!$product) die("Товар не найден");
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Редактирование</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="C:/OSPanel/home/example.local/магазин/css/style.css">
</head>
<body>
<div class="container mt-4">
    <h1>Редактировать товар</h1>
    <form action="update.php?id=<?= $id ?>" method="post" enctype="multipart/form-data">
        <div class="mb-3">
            <label>Название</label>
            <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($product['name']) ?>" required>
        </div>
        <div class="mb-3">
            <label>Цена</label>
            <input type="number" name="price" class="form-control" value="<?= $product['price'] ?>" required>
        </div>
        <div class="mb-3">
            <label>Ссылка на описание</label>
            <input type="text" name="informationlink" class="form-control" value="<?= htmlspecialchars($product['informationlink']) ?>" required>
        </div>
        <div class="mb-3">
            <label>Текущее изображение</label><br>
            <img src="<?= $product['img'] ?>" width="100">
            <input type="hidden" name="old_img" value="<?= basename($product['img']) ?>">
        </div>
        <div class="mb-3">
            <label>Новое изображение (оставьте пустым, если не меняете)</label>
            <input type="file" name="image" class="form-control">
        </div>
        <div class="mb-3 d-none">
            <input type="text" name="button" value="Подробнее">
        </div>
        <button type="submit" class="btn btn-primary">Сохранить изменения</button>
        <a href="read.php" class="btn btn-secondary">Назад</a>
    </form>
</div>
</body>
</html>