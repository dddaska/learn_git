<?php
$host = "127.0.1.28";
$user = "root";
$pass = "";
$db = "electronic-shop";
$port = 3306;

$connect = new mysqli($host, $user, $pass, $db, $port);
if ($connect->connect_error) die("Ошибка: " . $connect->connect_error);
$connect->set_charset("utf8mb4");
?>