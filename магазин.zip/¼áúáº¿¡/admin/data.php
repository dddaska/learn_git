<?php
require_once 'config.php';

$name = $_POST['name'];
$price = $_POST['price'];
$informationlink = $_POST['informationlink'];
$button = $_POST['button'];

$image = $_FILES['image'];
$newFileName = $image['name'];


$uploadPath = 'C:/OSPanel/home/example.local/магазин/img/' . $newFileName;
$dbImgPath = './img/' . $newFileName;

if (move_uploaded_file($image['tmp_name'], $uploadPath)) {
    $stmt = $connect->prepare("INSERT INTO products (name, price, informationlink, button, img) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sdsss", $name, $price, $informationlink, $button, $dbImgPath);
    $stmt->execute();
    $stmt->close();
    header("Location: read.php");
    exit;
} else {
    die("Ошибка при загрузке файла. Путь: " . $uploadPath);
}
?>