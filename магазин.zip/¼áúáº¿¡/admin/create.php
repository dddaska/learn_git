<?php require_once 'config.php'; ?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Добавление товара</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="C:/OSPanel/home/example.local/магазин/css/style.css">
</head>
<body>
<div class="container mt-4">
    <h1>Добавить товар</h1>
    <form action="data.php" method="post" enctype="multipart/form-data">
        <div class="mb-3">
            <label>Название</label>
            <input type="text" name="name" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Цена</label>
            <input type="number" name="price" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Ссылка на описание (informationlink)</label>
            <input type="text" name="informationlink" class="form-control" value="./" required>
        </div>
        <div class="mb-3">
            <label>Изображение</label>
            <input type="file" name="image" class="form-control" required>
        </div>
        <div class="mb-3 d-none">
            <input type="text" name="button" value="Подробнее">
        </div>
        <button type="submit" class="btn btn-primary">Сохранить</button>
        <a href="read.php" class="btn btn-secondary">Назад</a>
    </form>
</div>
</body>
</html>