<?php
require_once 'config.php';

$id = $_GET['id'];
$name = $_POST['name'];
$price = $_POST['price'];
$informationlink = $_POST['informationlink'];
$button = $_POST['button'];
$old_img = $_POST['old_img']; 

if ($_FILES['image']['name'] != "") {
    $image = $_FILES['image'];
    $fileName = $image['name'];
    move_uploaded_file($image['tmp_name'], "../img/$fileName");
    if ($old_img && file_exists("../img/$old_img") && $old_img != $fileName) {
        unlink("../img/$old_img");
    }
    $dbImgPath = './img/' . $fileName;
    $connect->query("UPDATE products SET 
                     name='$name', price='$price', informationlink='$informationlink', button='$button', img='$dbImgPath' 
                     WHERE id=$id");
} else {
    $connect->query("UPDATE products SET 
                     name='$name', price='$price', informationlink='$informationlink', button='$button' 
                     WHERE id=$id");
}

header("Location: read.php");
exit;
?>