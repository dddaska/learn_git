<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
</head>
<body>
    <main>
        <form action="./data.php" method="post" enctype="multipart/form-data">
            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">name</label>
                <input type="text" class="form-control" id="exampleInputEmail1" name="name">
            </div>
            <div class="mb-3 d-none">
                <label for="exampleInputButton" class="form-label">button</label>
                <input type="hidden" class="form-control" id="exampleInputButton" value="Подробнее"name="button">
            </div>
            <div class="mb-3 ">
                <label for="exampleInputImg" class="form-label">img</label>
                <input type="file" class="form-control" id="exampleInputImg" name="img">
            </div>
            <div class="mb-3">
                <label for="exampleInputLink" class="form-label">informationlink</label>
                <input type="text" class="form-control" id="exampleInputLink" name="informationlink">
            </div>
            <div class="mb-3 ">
                <label for="exampleInputPtice" class="form-label">price</label>
                <input type="number" class="form-control" id="exampleInputPtice" name="price">
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </main>
</body>
</html>