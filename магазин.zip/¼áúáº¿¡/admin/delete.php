<?php
require_once 'config.php';
$id = $_GET['id'];

$res = $connect->query("SELECT img FROM products WHERE id=$id");
$imgPath = $res->fetch_assoc()['img'];
if ($imgPath && file_exists("../" . $imgPath)) {
    unlink("../" . $imgPath);
}

$connect->query("DELETE FROM products WHERE id=$id");
header("Location: read.php");
exit;
?>