<?php
require_once 'config.php';
$result = $connect->query("SELECT * FROM products");
$products = $result->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Список товаров</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="C:/OSPanel/home/example.local/магазин/css/style.css">
</head>
<body>
<div class="container mt-4">
    <h1>Управление товарами</h1>
    <a href="create.php" class="btn btn-success mb-3">➕ Добавить товар</a>
    <table class="table table-bordered">
        <thead>
            <tr><th>ID</th><th>Название</th><th>Цена</th><th>Картинка</th><th>Действия</th></tr>
        </thead>
        <tbody>
        <?php foreach ($products as $product): ?>
        <tr>
            <td><?= $product['id'] ?></td>
            <td><?= htmlspecialchars($product['name']) ?></td>
            <td><?= $product['price'] ?> руб.</td>
            <td><img src="../img/<?= basename($product['img']) ?>" width="50"></td>
            <td>
                <a href="edit.php?id=<?= $product['id'] ?>" class="btn btn-primary btn-sm">Редактировать</a>
                <a href="delete.php?id=<?= $product['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Удалить товар?');">Удалить</a>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
</body>
</html>