<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Магазин электроники</title>
    <link rel="stylesheet" href="./css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
</head>
<body>
    <header>
        <nav>
            <ul class="nav justify-content-center">
                <li class="nav-item">
                    <a class="nav-link active" href="./index.php">Главная страница</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="./catalog.php">Каталог</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="./onas.php">О нас</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="./contacts.php">Контакты</a>
                </li>
            </ul>
        </nav>
    </header>
    <main>