<?php
include "header.php";
require_once "config.php";

$result = $connect->query("SELECT * FROM products");
$products = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
?>
<section class="our-tovar">
    <h3>Наши товары</h3>
    <div class="tovars">
        <?php foreach ($products as $product) : ?>
            <div class="tovars1">
                <div class="tovars-img">
                    <img src="<?php echo $product['img']; ?>" alt="" width="250">
                </div>
                <div class="tovars-info">
                    <p><?php echo $product['name'] ?></p>
                    <a href="<?php echo $product['informationlink']; ?>"><?php echo $product['button']; ?></a>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</section>
<?php
include "footer.php";
?>