-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Хост: MySQL-8.4:3306
-- Время создания: Апр 16 2026 г., 10:39
-- Версия сервера: 8.4.6
-- Версия PHP: 8.3.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `electronic-shop`
--

-- --------------------------------------------------------

--
-- Структура таблицы `products`
--

CREATE TABLE `products` (
  `id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `button` varchar(9) NOT NULL DEFAULT 'Подробнее',
  `img` varchar(255) NOT NULL,
  `informationlink` varchar(100) NOT NULL,
  `price` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `products`
--

INSERT INTO `products` (`id`, `name`, `button`, `img`, `informationlink`, `price`) VALUES
(1, 'Умные смарт часы Smart Watch DT No.1 с беспроводной зарядкой, 45 мм', 'Подробнее', './img/watch.jpg', './watch.php', 3659),
(2, 'Портативный аккумулятор Яндекс для Станции Мини 3 Про с Алисой, черный (YNDX-00650)', 'Подробнее', './img/alisa.jpg', './alisa.php', 2799),
(3, 'Электронная книга Onyx boox Дарвин 11 Black', 'Подробнее', './img/elkniga.jpg', './elkniga.php', 21990),
(4, 'Умная колонка Sber SberBoom с GigaChat 2.0, 40 Вт, серый', 'Подробнее', './img/kolonka.jpg', './kolonka.php', 8999),
(5, 'Аппаратный криптокошелек Ellipal X Card', 'Подробнее', './img/kriptokoshelek.jpg', './kriptokoshelek.php', 7990),
(6, 'MP3-плеер Digma B5B', 'Подробнее', './img/pleer.jpg', './pleer.php', 2999),
(7, 'Робот-пылесос Dreame D10s белый', 'Подробнее', './img/pulesos.jpg', './pulesos.php', 29999),
(8, 'Шлем виртуальной реальности Sony PlayStation VR2', 'Подробнее', './img/shlemvr.jpg', './shlemvr.php', 47999),
(9, 'Фитнес-браслет Xiaomi Smart Band 8 Pro M2333B1 Light Grey BHR8007GL (X53478)', 'Подробнее', './img/smartbar.jpg', './smartbar.php', 5399),
(10, 'Центр умного дома Яндекс Хаб YNDX-00510', 'Подробнее', './img/smarthome.jpg', './smarthome.php', 4499),
(11, 'Смарт-кольцо Sber размер 11, матовый черный (SBDV-00190A11)', 'Подробнее', './img/smartring.jpg', './smartring.php', 24999),
(12, 'Смарт-часы Huawei Watch GT 5 41mm White', 'Подробнее', './img/smartwatch.jpg', './smartwatch.php', 14999);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `products`
--
ALTER TABLE `products`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
